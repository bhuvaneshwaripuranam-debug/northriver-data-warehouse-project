Add your Power BI file (.pbix) here. dashboard.png is a screenshot of the report.
