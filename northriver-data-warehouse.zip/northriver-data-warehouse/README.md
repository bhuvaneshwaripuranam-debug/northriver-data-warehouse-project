# NorthRiver Data Warehouse

A star-schema data warehouse built from the NorthRiver PostgreSQL OLTP database, loaded by an automated Databricks pipeline and served to Power BI.

## Architecture
PostgreSQL OLTP (customers, products, channels, orders, order lines) -> staging tables in Databricks -> star schema in `northriver_warehouse` -> Power BI dashboard.
The Databricks job `northriver_nightly_pipeline` runs the extract, transform and load tasks nightly at 02:00 (Europe/Berlin).

## Design choices
- **Fact grain:** `fact_orders`, one row per order line item. Revenue is `net_amount`.
- **Dimensions:** `dim_customer`, `dim_product`, `dim_channel`, `dim_date`, with integer surrogate keys (`_sk`).
- **SCD Type 2:** `dim_customer` and `dim_product`, using `effective_from`, `effective_to` and `is_current`.
- **Loading order:** dimensions first, then `fact_orders`.

## Validation
Row counts, join completeness, fan-out prevention, revenue reconciliation and an SCD Type 2 simulation all passed. See `docs/` for details.

## Repository structure
| Folder | Contents |
|---|---|
| `docs/` | Executive report and short summary PDF |
| `sql/oltp/` | Initial SQL scripts for the OLTP source (created in Beekeeper Studio) |
| `databricks/notebooks/` | Extract, transform and load notebooks, plus job screenshot |
| `powerbi/` | Power BI dashboard file and screenshot |

## Limitation and next steps
Dimensions sync in batches, so late-arriving orders can briefly lack a dimension match. Next: fallback keys for unknown dimensions, schema-drift detection, and customer cohort metrics in Power BI.
