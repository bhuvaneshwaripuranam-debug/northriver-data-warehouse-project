Add the initial OLTP SQL scripts saved from Beekeeper Studio here (.sql files).
